-- Luanti / Voxera — install games from a local ContentDB .zip (no online fetch)
-- SPDX-License-Identifier: LGPL-2.1-or-later

local PATH_DIALOG = "dlg_local_game_zip"
local PICK_BUTTON = "local_game_pick"
local SITE_LINK = "site_link"
local URL_ACTION = "open_url"

local STATUS = {
	installing = "installing",
	ok = "ok",
	bad_file = "bad_file",
	error = "error",
}

local function zh_menu(en, zh)
	local t = fgettext(en)
	if t == nil or t == en or t == "" then
		return zh
	end
	return t
end

local function fs(...)
	local n = select("#", ...)
	local parts = {}
	for i = 1, n do
		local v = select(i, ...)
		if v == nil then
			v = ""
		end
		parts[i] = tostring(v)
	end
	return table.concat(parts)
end

local function layout_metrics()
	local size = { x = 15, y = 10 }
	local padding = { x = 0.5, y = 0.5 }
	if contentdb and contentdb.get_formspec_size and contentdb.get_formspec_padding then
		size = contentdb.get_formspec_size() or size
		padding = contentdb.get_formspec_padding() or padding
	end
	size.x = tonumber(size.x) or 15
	size.y = tonumber(size.y) or 10
	padding.x = tonumber(padding.x) or 0.5
	padding.y = tonumber(padding.y) or 0.5
	local btn_h = 0.8
	local bottom_y = size.y - btn_h - padding.y
	return size, padding, btn_h, bottom_y
end

local function pick_box_formspec(x, y, w, h, border)
	return fs(
		"box[", x, ",", y, ";", w, ",0.06;", border, "]",
		"box[", x, ",", y + h - 0.06, ";", w, ",0.06;", border, "]",
		"box[", x, ",", y, ";0.06,", h, ";", border, "]",
		"box[", x + w - 0.06, ",", y, ";0.06,", h, ";", border, "]"
	)
end

local function append_status_slot(parts, dlgdata, tex_dir, pick_w, pick_h, gap, border)
	local status = dlgdata.install_status
	if not status then
		return
	end

	local slot_x = pick_w + gap
	local icon = 0.55
	local icon_x = slot_x + (pick_w - icon) / 2
	local icon_y = (pick_h - icon) / 2
	local loading_tex = core.formspec_escape(tex_dir .. "cdb_downloading.png") or ""
	local ok_tex = core.formspec_escape(tex_dir .. "checkbox_64.png") or ""
	local err_tex = core.formspec_escape(tex_dir .. "error_icon_red.png") or ""

	parts[#parts + 1] = pick_box_formspec(slot_x, 0, pick_w, pick_h, border)

	if status == STATUS.installing then
		parts[#parts + 1] = fs(
			"animated_image[", icon_x, ",", icon_y, ";", icon, ",", icon,
			";slot_loading;", loading_tex, ";3;400;;]"
		)
	elseif status == STATUS.ok then
		parts[#parts + 1] = fs(
			"image[", icon_x, ",", icon_y, ";", icon, ",", icon, ";", ok_tex, "]"
		)
	else
		parts[#parts + 1] = fs(
			"image[", icon_x, ",", icon_y, ";", icon, ",", icon, ";", err_tex, "]"
		)
	end

	local caption = dlgdata.status_text or ""
	if caption ~= "" then
		parts[#parts + 1] = fs(
			"label[", slot_x, ",", pick_h + 0.08, ";", pick_w, ",0.42;",
			core.formspec_escape(caption), "]"
		)
	end
end

local function get_formspec(dlgdata)
	dlgdata = dlgdata or {}
	local size, padding, btn_h, bottom_y = layout_metrics()
	local pick_w = 2.5
	local pick_h = 2.5
	local gap = 0.35
	local link_w = 8.5
	local border = "#aaaaaa"
	local inner = pick_w - 0.12

	local url_raw = "https://content.luanti.org/"
	if local_install and local_install.get_download_url then
		url_raw = local_install.get_download_url() or url_raw
	end
	local site_hint = zh_menu("Open website to download packages", "打开网址下载包")
	local site_markup = "<global halign=right>" ..
			core.hypertext_escape(site_hint) .. "\n" ..
			"<style color=#ff6666><action name=\"" .. URL_ACTION .. "\">" ..
			core.hypertext_escape(url_raw) .. "</action></style></global>"

	local tex_dir = defaulttexturedir or ""
	local plus_img = core.formspec_escape(tex_dir .. "plus.png") or ""

	local top_parts = {
		"container[", padding.x, ",", padding.y, "]",
		pick_box_formspec(0, 0, pick_w, pick_h, border),
		"style[", PICK_BUTTON, ";border=false;bgcolor=#00000000]",
		"style[", PICK_BUTTON, ":hovered;bgcolor=#ffffff12]",
		"style[", PICK_BUTTON, ":pressed;bgcolor=#ffffff22]",
		"button[0.12,0.12;", inner, ",", inner, ";", PICK_BUTTON, ";]",
		"image[", pick_w / 2 - 0.75, ",", pick_h / 2 - 0.75, ";1.5,1.5;", plus_img, "]",
		"tooltip[", PICK_BUTTON, ";",
			zh_menu("Open downloaded package locally", "本地打开下载的包"), "]",
	}
	append_status_slot(top_parts, dlgdata, tex_dir, pick_w, pick_h, gap, border)
	top_parts[#top_parts + 1] = "container_end[]"

	local out = {
		"formspec_version[6]",
		"size[", size.x, ",", size.y, "]",
		"padding[0,0]",
		"bgcolor[;true]",
	}
	for i = 1, #top_parts do
		out[#out + 1] = top_parts[i]
	end
	out[#out + 1] = "container["
	out[#out + 1] = padding.x
	out[#out + 1] = ","
	out[#out + 1] = bottom_y
	out[#out + 1] = "]"
	out[#out + 1] = "button[0,0;2,"
	out[#out + 1] = btn_h
	out[#out + 1] = ";back;"
	out[#out + 1] = zh_menu("Back", "返回")
	out[#out + 1] = "]"
	out[#out + 1] = "container_end[]"
	out[#out + 1] = "container["
	out[#out + 1] = size.x - padding.x - link_w
	out[#out + 1] = ","
	out[#out + 1] = bottom_y
	out[#out + 1] = "]"
	out[#out + 1] = "hypertext[0,0;"
	out[#out + 1] = link_w
	out[#out + 1] = ",0.82;;"
	out[#out + 1] = core.formspec_escape(site_markup) or ""
	out[#out + 1] = "]"
	out[#out + 1] = "container_end[]"
	return fs(unpack(out))
end

local function apply_install_result(dlg, result)
	if result and result.ok then
		dlg.data.install_status = STATUS.ok
		dlg.data.status_text = ""
		pkgmgr.reload_by_type(result.content_type or "game")
		if singleplayer_refresh_gamebar then
			singleplayer_refresh_gamebar()
		end
		local gameid = result.path and pkgmgr.normalize_game_id(result.path:match("[^/\\]+[/\\]?$"))
		if gameid then
			core.settings:set("menu_last_game", gameid)
		end
		ui.update()
		return
	end

	if result and result.bad_file then
		dlg.data.install_status = STATUS.bad_file
		dlg.data.status_text = zh_menu("Incorrect file", "文件不正确")
	elseif result and result.error then
		dlg.data.install_status = STATUS.error
		dlg.data.status_text = result.error_msg
			or zh_menu("Other error", "其他错误")
	else
		dlg.data.install_status = STATUS.error
		dlg.data.status_text = result and result.error_msg
			or zh_menu("Other error", "其他错误")
	end
	ui.update()
end

local function run_install(dlg, zip_path)
	dlg.data.install_status = STATUS.installing
	dlg.data.status_text = zh_menu("Installing...", "安装中")
	ui.update()

	local function short_err(msg)
		if not msg or msg == "" then
			return zh_menu("Other error", "其他错误")
		end
		msg = tostring(msg)
		if #msg > 72 then
			return msg:sub(1, 69) .. "..."
		end
		return msg
	end

	local function finish_install(extracted_path, game_basename)
		if local_install and local_install.ohos_status then
			local_install.ohos_status("local_install: install to games")
		end
		core.create_dir(core.get_gamepath())
		local path, msg = pkgmgr.install_dir("game", extracted_path, game_basename, nil)
		if extracted_path and extracted_path ~= "" then
			core.delete_dir(extracted_path)
		end
		if not path then
			core.log("warning", "local_install dlg: " .. tostring(msg))
			if local_install and local_install.ohos_status then
				local_install.ohos_status("local_install: " .. tostring(msg))
			end
			apply_install_result(dlg, { error = true, error_msg = short_err(msg) })
			return
		end
		apply_install_result(dlg, { ok = true, path = path, content_type = "game" })
	end

	local function do_install(extracted_path, game_basename)
		dlg:show()
		dlg.data.install_status = STATUS.installing
		dlg.data.status_text = zh_menu("Installing...", "安装中")
		ui.update()
		finish_install(extracted_path, game_basename)
	end

	local function process_extracted(info)
		if not info then
			apply_install_result(dlg, { error = true })
			return
		end
		if info.bad_file or info.error then
			apply_install_result(dlg, info)
			return
		end
		if not info.path then
			apply_install_result(dlg, { error = true })
			return
		end

		local basefolder = pkgmgr.get_base_folder(info.path)
		if not basefolder or basefolder.type ~= "game" then
			core.delete_dir(info.path)
			apply_install_result(dlg, { bad_file = true })
			return
		end

		local conf = Settings(basefolder.path .. DIR_DELIM .. "game.conf")
		local raw_name = conf and conf:get("name") or basefolder.path:match("[^/\\]+[/\\]?$")
		local name = pkgmgr.normalize_game_id(raw_name)
		if name and core.is_dir(core.get_gamepath() .. DIR_DELIM .. name) then
			local package = {
				name = name,
				title = (conf and conf:get("title")) or raw_name or name,
				type = "game",
			}
			local confirm = create_confirm_overwrite(package, function()
				do_install(info.path, name)
			end)
			confirm:set_parent(dlg)
			dlg:hide()
			confirm:show()
			ui.update()
			return
		end

		finish_install(info.path, name)
	end

	-- Main menu has no core.after; extract on the menu thread (not async workers).
	if not local_install or not local_install.extract_to_temp then
		apply_install_result(dlg, { error = true })
		return
	end
	if local_install.ohos_status then
		local_install.ohos_status("local_install: begin")
	end
	process_extracted(local_install.extract_to_temp(zip_path))
end

local function handle_submit(dlg, fields)
	if fields.back then
		dlg:delete()
		return true
	end

	if fields[PICK_BUTTON] then
		core.show_path_select_dialog(PATH_DIALOG,
				zh_menu("Select package", "选择安装包"), true)
		return true
	end

	if fields[PATH_DIALOG .. "_accepted"] then
		local path = fields[PATH_DIALOG .. "_accepted"]
		if path and path ~= "" then
			run_install(dlg, path)
		end
		return true
	end

	if fields[SITE_LINK] then
		local event = core.explode_table_event(fields[SITE_LINK])
		if event and event.type == "CL" and event.action == URL_ACTION then
			local url = "https://content.luanti.org/"
			if local_install and local_install.get_download_url then
				url = local_install.get_download_url() or url
			end
			core.open_url(url)
		end
		return true
	end

	return false
end

local function handle_events(event)
	if event == "DialogShow" then
		mm_game_theme.set_engine(true)
		return true
	end
	return false
end

function create_local_game_install_dlg()
	local dlg = dialog_create("local_game_install", get_formspec, handle_submit, handle_events)
	dlg.data.install_status = nil
	dlg.data.status_text = ""
	return dlg
end
